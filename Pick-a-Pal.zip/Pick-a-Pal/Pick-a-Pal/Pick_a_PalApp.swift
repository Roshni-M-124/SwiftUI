//
//  Pick_a_PalApp.swift
//  Pick-a-Pal
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

@main
struct Pick_a_PalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
