//
//  ContentView.swift
//  Pick-a-Pal
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct Person: Identifiable{
    let id = UUID()
    let name: String
    var phoneNumber = ""
    var email = ""
    var notes = ""
}
struct ContentView: View {
    @State private var people: [Person] = []
    @State private var savedPeople: [Person] = []
    @State private var nameToAdd = ""
    @State private var pickedName = ""
    @State private var shouldRemovePickedName = false
    
    var body: some View {
        NavigationStack {
            VStack {
                VStack(spacing: 8) {
                    Image(systemName: "person.3.sequence.fill")
                        .foregroundStyle(.tint)
                        .symbolRenderingMode(.hierarchical)
                    Text("Pick-a-Pal")
                }
                .font(.title)
                .bold()
                
                Text(pickedName.isEmpty ? " " : pickedName)
                    .font(.title2)
                    .bold()
                    .foregroundStyle(.tint)
                
                List{
                    ForEach($people){$person in
                        NavigationLink{
                            PersonDetailView(person: $person)
                        }label: {
                            Text(person.name)
                        }
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 20))
                HStack(spacing: 30){
                    Button{
                        savedPeople.removeAll()
                        savedPeople = people
                    }label: {
                        Text("Save Names")
                            .padding(.vertical,5)
                            .padding(.horizontal,5)
                    }
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    
                    Button{
                        people = savedPeople
                    }label: {
                        Text("Load Names")
                            .padding(.vertical,5)
                            .padding(.horizontal,5)
                    }
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                }
                .padding(10)
                TextField("Add Name", text: $nameToAdd)
                    .autocorrectionDisabled()
                    .onSubmit {
                        let trimmedName = nameToAdd.trimmingCharacters(in: .whitespacesAndNewlines)
                        let alreadyExists = people.contains{
                            $0.name == trimmedName
                        }
                        if !trimmedName.isEmpty && !alreadyExists{
                            let newPerson = Person(name: trimmedName)
                            people.append(newPerson)
                        }
                        nameToAdd = ""
                    }
                    .padding()
                Divider()
                Toggle("Remove Name when picked", isOn: $shouldRemovePickedName)
                
                Button{
                    if let randomPerson = people.randomElement() {
                        pickedName = randomPerson.name
                        
                        if shouldRemovePickedName{
                            people.removeAll{ person in
                                person.name == pickedName
                            }
                        }
                    }else{
                        pickedName = ""
                    }
                }label: {
                    Text("Pick Random Name")
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                }
                .buttonStyle(.borderedProminent)
                .font(.title2)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
