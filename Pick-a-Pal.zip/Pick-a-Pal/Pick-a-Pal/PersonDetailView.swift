//
//  PersonDetailView.swift
//  Pick-a-Pal
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct PersonDetailView: View {
    @Binding var person: Person
    
    var body: some View {
        Form{
            Section("Person"){
                Text(person.name)
                    .font(.headline)
            }
            Section("Contact Details"){
                TextField("Phone Number", text: $person.phoneNumber)
                    .keyboardType(.phonePad)
                
                TextField("Email",text: $person.email)
                    .keyboardType(.emailAddress)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            }
            Section("Notes"){
                TextField(" Add Notes", text: $person.notes, axis: .vertical)
                    .lineLimit(4...8)
            }
        }
        .navigationTitle(person.name)
    }
}

#Preview {
    ContentView()
}
