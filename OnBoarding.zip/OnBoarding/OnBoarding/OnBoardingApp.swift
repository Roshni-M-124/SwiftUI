//
//  OnBoardingApp.swift
//  OnBoarding
//
//  Created by Mobicip on 18/05/26.
//

import SwiftUI

@main
struct OnBoardingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
