//
//  ContentView.swift
//  OnBoarding
//
//  Created by Mobicip on 18/05/26.
//

import SwiftUI

let gradientColors: [Color] = [.gradientTop, .gradientBottom]
struct ContentView: View {
    var body: some View {
        TabView{
            WelcomPage()
            FeaturesPage()
        }
        .background(Gradient(colors: gradientColors))
        .tabViewStyle(.page)
        .foregroundStyle(.white)
    }
}

#Preview {
    ContentView()
}
