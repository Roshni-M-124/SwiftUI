//
//  WelcomPage.swift
//  OnBoarding
//
//  Created by Mobicip on 18/05/26.
//

import SwiftUI

struct WelcomPage: View {
    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                RoundedRectangle(cornerRadius: 30)
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.blue)
                
                Image(systemName: "figure.2.and.child.holdinghands")
                    .font(.system(size: 70))
                    .foregroundStyle(.white)
            }
            
            Text("Welcome To")
                .font(.largeTitle)
                .fontWeight(.semibold)
                .fontDesign(.rounded)
                .padding(.top,10)
            
            Text("Mobicip")
                .font(.title)
                .multilineTextAlignment(.center)
                .frame(width: 250)
        }
        .padding(15)
    }
}

#Preview {
    WelcomPage()
}
