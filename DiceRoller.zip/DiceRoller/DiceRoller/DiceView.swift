//
//  DiceView.swift
//  DiceRoller
//
//  Created by Mobicip on 19/05/26.
//

import SwiftUI

struct DiceView: View {
   @State private var numberofPips: Int = 1
    var body: some View {
        VStack{
            Image(systemName: "die.face.\(numberofPips).fill")
                .resizable()
                .frame(maxWidth: 100,maxHeight: 100)
                .aspectRatio(1,contentMode: .fit)
                .foregroundStyle(.black,.white)
                .padding()
            Button("Roll"){
                withAnimation{
                    numberofPips = Int.random(in: 1...6)
                }
            }
            .buttonStyle(.bordered)
        }
        
    }
}

#Preview {
    DiceView()
}
