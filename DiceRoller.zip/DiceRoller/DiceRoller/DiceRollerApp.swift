//
//  DiceRollerApp.swift
//  DiceRoller
//
//  Created by Mobicip on 19/05/26.
//

import SwiftUI

@main
struct DiceRollerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
