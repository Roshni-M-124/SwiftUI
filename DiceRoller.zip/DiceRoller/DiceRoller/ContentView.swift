//
//  ContentView.swift
//  DiceRoller
//
//  Created by Mobicip on 19/05/26.
//

import SwiftUI

struct ContentView: View {
    @State private var numberofDice: Int = 1
    var body: some View {
        VStack {
            Text("Dice Roller")
                .font(.largeTitle.lowercaseSmallCaps())
                .foregroundStyle(.white)
            HStack{
                ForEach(1...numberofDice, id: \.description){_ in
                    DiceView()
                }
            }
            HStack{
                Button("Remove Dice", systemImage: "minus.circle.fill"){
                    withAnimation{
                        numberofDice -= 1
                    }
                }
                .disabled(numberofDice == 1)
                Button("Add Dice",systemImage: "plus.circle.fill"){
                    withAnimation{
                        numberofDice += 1
                    }
                }
                .disabled(numberofDice == 5)
            }
            .padding()
            .labelStyle(.iconOnly)
            .font(.title)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .background(.appBackground)
        .tint(.white)
    }
}

#Preview {
    ContentView()
}
