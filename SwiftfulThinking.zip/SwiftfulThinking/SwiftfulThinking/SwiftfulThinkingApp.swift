//
//  SwiftfulThinkingApp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

@main
struct SwiftfulThinkingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
