//
//  ShapeBootcamp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct ShapeB: View {
    var body: some View {
        
//        Circle()
//            .fill(.blue)
//            .foregroundStyle(.blue) // both are to fill
//            .stroke(.blue)
//           .stroke(.blue,lineWidth: 5)
//           .stroke(.orange, style: StrokeStyle(lineWidth: 20, lineCap: .butt, dash: [10]))
//            .trim(from: 0.2,to:1.0) //0 to 1 is value change to display oly portion of the shape
//            .stroke(.purple,lineWidth: 50) //xombine stroke with trim to create shapes for loading indicator ..
        
//        Ellipse()
//            .frame(width: 200,height: 100)
        
//        Capsule(style: .continuous)
//            .frame(width: 200,height: 100)
        
//        Rectangle()
//        RoundedRectangle(cornerSize: 20)
        //for all the above shape all the modifiers are applicable
        
        
    }
}

#Preview {
    ShapeB()
}
