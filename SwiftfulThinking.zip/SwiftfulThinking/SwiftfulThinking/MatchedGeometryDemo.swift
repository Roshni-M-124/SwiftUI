//
//  MatchedGeometryDemo.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//


import SwiftUI

struct MatchedGeometryDemo: View {
    @Namespace var animation

    @State var showDetail = false
        
    var body: some View {
        ZStack {
            if (!showDetail) {
                VStack (alignment: .leading){
                    Text("Title")
                            .matchedGeometryEffect(id: "title", in: animation)
                            .font(.largeTitle.bold())
                            .foregroundStyle(Color.white)
                    
                    Text("Subtitle")
                        .matchedGeometryEffect(id: "subtitle", in: animation)
                        .font(.title3.bold())
                        .foregroundStyle(Color.white)


                }
                .padding(.all, 20)
                .padding(.trailing, 50)
                .background(
                    Color(UIColor.gray)
                        .matchedGeometryEffect(id: "background", in: animation)

                )
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.all, 20)

            } else {
                DetailView(animation: animation)

            }
        }
        .onTapGesture {
            withAnimation {
                showDetail.toggle()
            }
        }
    }
}



fileprivate struct DetailView: View {
    var animation: Namespace.ID

    var body: some View {
        VStack{
            Text("Title")
                    .matchedGeometryEffect(id: "title", in: animation)
                    .font(.largeTitle.bold())
                    .foregroundStyle(Color.white)
            
            Text("Subtitle")
                .matchedGeometryEffect(id: "subtitle", in: animation)
                .font(.title3.bold())
                .foregroundStyle(Color.white)

            Spacer()
                .frame(height: 30)
            Text("Some Details\n MoreDetails")
                .font(.subheadline.bold())
                .foregroundStyle(Color.white)
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .padding(.all, 20)
        .background(
            Color(UIColor.gray)
                .matchedGeometryEffect(id: "background", in: animation)
                .ignoresSafeArea(.all)
        )
        
    }
}


#Preview {
    return MatchedGeometryDemo()
}
