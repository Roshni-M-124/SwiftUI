//
//  Text.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct TextB: View {
    var body: some View {
        Text("HELLO WORLD! this is the swiftful thinking bootcamp. I am really enjoying this course a lot and I am learning so much.")
//            .font(.body)
//            .fontWeight(.semibold)
//            .bold()
//            .italic()
//            .underline()
//            .underline(true,pattern: .dashDotDot,color: .red)
//            .strikethrough()
//            .strikethrough(pattern: .dash,color: .blue)
//            .font(.system(size: 24,weight: .semibold,design: .rounded))//this font size dont resize based on device font size  but .font(.title) this will resize
//            .baselineOffset(10)//spacing below lines. if value is -10 spacing above lines
//            .kerning(1.5) //spacing between each letter
            .foregroundStyle(.blue) //font colour
            .multilineTextAlignment(.leading)
            .frame(width: 200,height: 200,alignment: .center)
            .minimumScaleFactor(0.1) //when content increases the font will cut of this allows the font size to reduce by 10% to fit in (value of 0.1 means reduce by 10%)
        
        Text("hello world".capitalized) //.uppercased()) //captilatized captializes starting letter in every word
        //automatically in centre to bring this to leading
            .frame(width: 200,alignment: .leading)
    }
}

#Preview {
    TextB()
}
