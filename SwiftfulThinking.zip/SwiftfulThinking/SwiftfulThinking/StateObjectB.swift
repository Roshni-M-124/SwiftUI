//
//  StateObjectB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 26/05/26.
//

import SwiftUI
internal import Combine

struct FruitModel : Identifiable{
    let id : String = UUID().uuidString
    let name: String
    let count: Int
    
}

class FruitViewModel: ObservableObject{
    //published is same as state but within class
    @Published var fruitArray: [FruitModel] = []
    @Published var isLoading: Bool = false
    
    func getFruits(){
        let fruit1 = FruitModel(name: "Oranges", count: 1)
        let fruit2 = FruitModel(name: "Banana", count: 2)
        let fruit3 = FruitModel(name: "Watermelon", count: 8)
        
        isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now()+2){ [self] in
            self.fruitArray = [fruit1,fruit2,fruit3]
            self.isLoading = false
        }
    }
    
    func deleteFruits(index: IndexSet){
        fruitArray.remove(atOffsets: index)
    }
        
}

struct StateObjectB: View {
    
   //StateObject -> use this on creation/ init
    //ObservableObject -> use this for subview
    
    @StateObject private var fruitViewModel: FruitViewModel = FruitViewModel()
    
    var body: some View {
        NavigationView{
            List{
                if fruitViewModel.isLoading{
                    ProgressView()
                }else{
                    ForEach(fruitViewModel.fruitArray){ fruit in
                        HStack{
                            Text("\(fruit.count)")
                                .foregroundStyle(.red)
                            Text(fruit.name)
                                .font(.headline)
                                .bold()
                        }
                    }
                    .onDelete(perform: fruitViewModel.deleteFruits)
                }
            }
            .listStyle(.grouped)
            .navigationTitle("Fruit List")
            .toolbar(content: {
                ToolbarItem(placement: .topBarTrailing, content: {
                    NavigationLink( destination: Screen( fruitViewModel: fruitViewModel), label: {
                        Image(systemName: "arrow.right")
                            .font(.title)
                    })
                    
                })
            })
            .onAppear{
                fruitViewModel.getFruits()
            }
        }
    }
}

struct Screen: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var fruitViewModel: FruitViewModel
    var body: some View {
        ZStack{
            Color.green.ignoresSafeArea(.all)
            
            VStack{
                ForEach(fruitViewModel.fruitArray){fruit in
                    Text(fruit.name)
                        .foregroundStyle(.white)
                        .font(.headline)
                }
            }
        }
    }
}

#Preview {
    StateObjectB()
    
}
