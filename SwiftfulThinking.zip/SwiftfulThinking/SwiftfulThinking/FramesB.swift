//
//  FramesB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct FramesB: View {
    var body: some View {
        Text("Hello, World! heyy u there ")
            .background(.green)
            //.frame(width: 300,height: 300,alignment: .leading) //fixed frame size
            .frame(maxWidth: .infinity,maxHeight: .infinity,alignment:.leading ) //set maxwidth to infinity and alignment to leading to get the text start from left
        //alignment is always align this view in where with respective to the superview
            .background(.red)
    }
}

#Preview {
    FramesB()
}
