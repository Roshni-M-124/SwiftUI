//
//  GradientBootcamp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct GradientB: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(
                //.red
               // LinearGradient(colors: [.pink, .custom], startPoint: .topLeading, endPoint: .bottomTrailing)
                AngularGradient(colors: [.pink,.custom], center: .topLeading, angle: .degrees(180+45))
                
            )
            .frame(width: 200,height: 100)
    }
}

#Preview {
    GradientB()
}
