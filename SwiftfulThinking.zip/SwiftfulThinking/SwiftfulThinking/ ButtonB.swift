//
//  Button.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct ButtonB: View {
    
  @State private var title:String = "This is my title"
    
    var body: some View {
        VStack(spacing:20) {
            Text(title)
            
            Button("Press Me"){
                self.title = "Button was pressed"
            }
            .accentColor(.red)
            
            Button(action: {
                self.title = "Button #2 was pressed"
            }, label: {
                Text("Save".uppercased())
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .padding(.horizontal,10)
                    .background(
                        Color.blue
                            .cornerRadius(10)
                            .shadow(radius: 10)
                    )
            })
            
            Button(action: {
                self.title = "Button #3 was pressed"
            }, label: {
                Circle()
                    .fill(Color.white)
                    .frame(width: 75,height: 75)
                    .shadow(radius: 10)
                    .overlay(
                        Image(systemName: "heart.fill")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                    )
            })
            
            Button(action: {
                self.title = "Button #4 was pressed"
            }, label: {
               /* Text("Finish".uppercased())
                    .font(.caption)
                    .bold()
                    .foregroundStyle(.gray)
                    .padding()
                    .padding(.horizontal,10)
                    .background(
                        Capsule()
                            .stroke(.gray,lineWidth: 2)
                    )
                */
                
                VStack{
                    Text("Hi")
                        .foregroundStyle(.blue)
                        .bold()
                        .font(.largeTitle)
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 200,height: 300)
                }
                .padding()
                HStack{
                    Text("Hii")
                    Circle()
                        .fill(Color.red)
                        .shadow(color:.black,radius: 2)
                }
                .padding()
                
            })
        }
    }
}

#Preview {
    ButtonB()
}
