//
//  TernaryB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct TernaryB: View {
    
    @State var isStartingState: Bool = false
    
    var body: some View {
        VStack(spacing:20){
            Button("Button: \(isStartingState.description)"){
                isStartingState.toggle()
                
            }
            
            Text(isStartingState ? "Is starting STATE" : "Is Ending STATE")
            /*
             if isStartingState{
                RoundedRectangle(cornerRadius: 25)
                    .fill(.red)
                    .frame(width: 200,height: 100)
            }else{
                RoundedRectangle(cornerRadius: 25)
                    .fill(.blue)
                    .frame(width: 200,height: 100)
            }
             */
            //efficient way to do
            RoundedRectangle(cornerRadius: 10)
                .fill(isStartingState ? .red : .blue )
                .frame(
                    width: isStartingState ? 200 : 50 ,
                    height: isStartingState ? 400 : 50
                )
            
            Spacer()
            
        }
    }
}

#Preview {
    TernaryB()
}
