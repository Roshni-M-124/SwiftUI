//
//  ForEachB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct ForEachB: View {
    
    let data: [String] = ["Hi","Hello","Hey Everyone"]
    
    var body: some View {
        VStack{
            ForEach(0..<10){ index in
                Text("Hi: \(index)")
            }
            
            ForEach(0..<10){index in
                HStack{
                    Circle()
                        .frame(width: 30,height: 30)
                    Text("Index is : \(index)")
                }
            }
            
            ForEach(data.indices, id: \.self){index in
                Text("\(data[index]): \(index)")
            }
        }
    }
}

#Preview {
    ForEachB()
}
