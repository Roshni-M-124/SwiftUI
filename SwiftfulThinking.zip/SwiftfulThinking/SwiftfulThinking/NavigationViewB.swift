//
//  NavigationViewB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct NavigationViewB: View {
    var body: some View {
        
        NavigationView {
            ScrollView{
                NavigationLink("Hello,World!", destination: MyOtherScreen())
                
                Text("Hello World")
                Text("Hello World")
                Text("Hello World")
            }
            .navigationTitle("Title")
            //.navigationBarTitleDisplayMode(.automatic)
           // .navigationBarHidden(true)//to disable title
            .navigationBarItems(
                leading:
                    HStack{
                        Image(systemName: "person.fill")
                        Image(systemName: "flame.fill")
                    }
                ,
                trailing:
                    NavigationLink(
                        destination: MyOtherScreen(),
                        label: {
                            Image(systemName: "gear")
                        })
                    .tint(.red)
            )
            
            
            
        }
    }
}

struct MyOtherScreen : View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        ZStack{
            Color.green.edgesIgnoringSafeArea(.all)
                .navigationTitle("Green Screen")
                .navigationBarBackButtonHidden(true)
            
            VStack{
                Button("Back Button"){
                    dismiss()
                }
                NavigationLink("click me", destination: Text("3rd Screen"))
            }
        }
    }
}

#Preview {
    NavigationViewB()
}
