//
//  IconsBootcamp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct IconsB: View {
    var body: some View {
        Image(systemName: "heart.fill")
            .renderingMode(.original)
           .resizable() // with frame
           // .aspectRatio(contentMode: .fit) //with frame
           .scaledToFill() // instead of aspect ratio
            //.font(.largeTitle)
            //.font(.system(size: 200)) //for custom sizing
            //.foregroundStyle(.red)
            .frame(width: 300,height: 300)
           // .clipped() //clip image exactly to frame
            .border(.blue)
    }
}

#Preview {
    IconsB()
}
