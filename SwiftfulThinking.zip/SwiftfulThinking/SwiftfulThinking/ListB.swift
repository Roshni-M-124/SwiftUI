//
//  ListB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 26/05/26.
//

import SwiftUI

struct Fruitmodel1: Identifiable {
    var id: String
    var name: String
}

struct ListB: View {
    
    @State var fruits:[Fruitmodel1] = [
        Fruitmodel1(id: UUID().uuidString, name: "Apple"),
        Fruitmodel1(id: UUID().uuidString, name: "Apple"),
        Fruitmodel1(id: UUID().uuidString, name: "Orange"),
        Fruitmodel1(id: UUID().uuidString, name: "Banana"),
        Fruitmodel1(id: UUID().uuidString, name: "Peach"),
        Fruitmodel1(id: UUID().uuidString, name: "Mango")
        ]
    @State var isFruitExpanded = true
    
    var body: some View {
        NavigationView {
            List{
                Section(isExpanded: $isFruitExpanded,content:{
                    ForEach(fruits, id: \.id ){fruit in
                        Text(fruit.name)
                    }
                    .onDelete(perform:deletefruit)
                   // .listRowBackground(Color.blue)
                    
                },
                        header: {
                    Text("Fruits")
                })
                .listStyle(.sidebar)
                //grpuped - title gray and text from leading edge
                //insetgrouped - title gray and content indent from leading
            }
            .navigationTitle("Grocery List")
            .toolbar{
                ToolbarItem(placement: .topBarLeading, content: {
                    EditButton()
                })
                ToolbarItem(placement: .topBarTrailing, content: {
                    Button("Add"){
                        add()
                    }
                    .foregroundStyle(.blue)
                    .bold()
                })
            }
        }
    }
    
    func deletefruit(indexSet: IndexSet){
        fruits.remove(atOffsets: indexSet)
    }
    
    func add(){
        fruits.append(Fruitmodel1(id: UUID().uuidString, name: "Coconut"))
    }
}
#Preview {
    ListB()
}
