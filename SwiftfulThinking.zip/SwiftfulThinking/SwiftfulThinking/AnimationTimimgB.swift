//
//  AnimationTimimgB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct AnimationTimimgB: View {
    
    @State var isAnimating: Bool = false
    let timing: Double = 10.0
    
    var body: some View {
        VStack{
            Button("Button"){
                isAnimating.toggle()
            }
            
            RoundedRectangle(cornerRadius: 20)
                .frame(width: isAnimating ? 350 : 100 ,height: 100)
                .animation(.spring(
                    response: 3.0,//timing
                    dampingFraction: 0.2 //bounce back less value more bounce 
                ), value: isAnimating)
 //               .animation(.spring, value: isAnimating)
//                .animation(.linear(duration: timing), value: isAnimating)//same timing from start to end
//            
//            RoundedRectangle(cornerRadius: 20)
//                .frame(width: isAnimating ? 350 : 50 ,height: 100)
//                .animation(.easeIn(duration: timing), value: isAnimating)//slow first fast as end
//            
//            RoundedRectangle(cornerRadius: 20)
//                .frame(width: isAnimating ? 350 : 50 ,height: 100)
//                .animation(.easeInOut(duration: timing), value: isAnimating)//slow fast slow
//            
//            RoundedRectangle(cornerRadius: 20)
//                .frame(width: isAnimating ? 350 : 50 ,height: 100)
//                .animation(.easeOut(duration: timing), value: isAnimating)//fast then slow
       }
    }
}

#Preview {
    AnimationTimimgB()
}
