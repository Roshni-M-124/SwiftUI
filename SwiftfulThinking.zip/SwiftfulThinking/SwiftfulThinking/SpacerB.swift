//
//  SpacerB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct SpacerB: View {
    var body: some View {
        HStack(spacing: 0){
            Spacer()
                .frame(height:10)
                .background(.orange)
            
            Rectangle()
                .frame(width: 50,height: 50)
            
            Spacer()
                .frame(height:10)
                .background(.orange)
            
            Rectangle()
                .fill(.red)
                .frame(width: 50,height: 50)
            
            Spacer()
                .frame(height:10)
                .background(.orange)
            
            Rectangle()
                .fill(.green)
                .frame(width: 50,height: 50)
            
            Spacer()
                .frame(height:10)
                .background(.orange)
                
        }
        //when we have multiple spacers inside a stack they will all resize such that all of them are of the same size .
        //u can use to have equal spacing between icons in ur app .
        
    }
}

#Preview {
    SpacerB()
}
