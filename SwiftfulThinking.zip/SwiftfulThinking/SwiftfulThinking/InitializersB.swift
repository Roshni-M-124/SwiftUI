//
//  InitializersB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct InitializersB: View {
    let backgroundColor: Color
    let count: Int
    let title: String
    
    /* custom init
     init (count: Int, title: String) {
        if title == "Oranges" {
            self.backgroundColor = Color.orange
        }
        else {
            self.backgroundColor = Color.red
        }
        self.count = count
        self.title = title
    }
     */
    
    init(count: Int, fruit: Fruit){
        self.count = count
        if fruit == .apples{
            self.title = "Apples"
            self.backgroundColor = Color.red
        }
        else{
            self.title = "Oranges"
            self.backgroundColor = Color.orange
        }

    }
    
    enum Fruit{
        case apples
        case oranges
    }
    
    var body: some View {
        VStack(spacing: 12){
            Text("\(count)")
                .font(.largeTitle)
                .foregroundStyle(.white)
                .underline()
            
            Text("\(title)")
                .font(.headline)
                .foregroundStyle(.white)
        }
        .frame(width: 150,height: 150)
        .background(backgroundColor)
        .cornerRadius(10)
    }
}

#Preview {
    //InitializersB(count: 55, title: "Orange") custom init
    //InitializersB(backgroundColor: .red, count: 55, title: "Apples")
   // InitializersB(count: 55, fruit: .oranges)
    
    HStack{
        InitializersB(count: 100, fruit: .oranges)
        InitializersB(count: 46, fruit: .apples)
    }
}
