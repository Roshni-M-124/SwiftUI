//
//  SafeAreaB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

//by default in swiftui all the content are within the safearea
struct SafeAreaB: View {
    var body: some View {
        ScrollView{
            VStack{
                Text("Title")
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity,alignment: .leading)
                
                ForEach(0..<10){ index in
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.white)
                        .frame(height: 150)
                        .shadow(radius: 10)
                        .padding(20)
                    
                }
            }
        }
        .background(.red)
        .border(.black)
        .background(
           Color.blue
            .ignoresSafeArea(edges:.all))
        
    }
}

#Preview {
    SafeAreaB()
}

