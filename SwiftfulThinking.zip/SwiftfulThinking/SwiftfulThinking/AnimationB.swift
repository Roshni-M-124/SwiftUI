//
//  AnimationB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct AnimationB: View {
    
    @State var isAnimated: Bool = false
    
    var body: some View {
        VStack{
            Button("Button"){
                withAnimation(
                    Animation
                        .default
                        //.delay(2.0) // to provide delay
                        .repeatCount(3, autoreverses: true)
                        //.repeatForever(autoreverses: true)
                ){
                    isAnimated.toggle()
                }
            }
            Spacer()
            RoundedRectangle(cornerRadius: isAnimated ? 50 : 25)
                .fill(isAnimated ? .red : .green)
                .frame(
                    width: isAnimated ? 100 : 300,
                    height: isAnimated ? 100 : 300)
                .rotationEffect(Angle(degrees: isAnimated ? 360 : 0))
                //.offset(y:isAnimated ? 300 : 0) // offset is to move the element
            Spacer()
        }
    }
}

#Preview {
    AnimationB()
}
