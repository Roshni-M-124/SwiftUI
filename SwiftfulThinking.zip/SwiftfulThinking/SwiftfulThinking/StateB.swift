//
//  StateB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct StateB: View {
    
    @State var backgroundColor = Color.green
    @State var title: String = "My Title"
    @State var count: Int = 0
    
    var body: some View {
        ZStack{
            //background
            backgroundColor
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing:20){
                Text(title)
                    .font(.title)
                Text("Count: \(count)")
                    .font(.headline)
                    .underline()
                HStack(spacing:20){
                    Button("Button 1"){
                        backgroundColor = .red
                        title = "Button 1 pressed"
                        count += 1
                    }
                    
                    Button("Button 2"){
                        backgroundColor = .purple
                        title = "Button 2 was pressed"
                        count -= 1
                    }
                }
            }
            .foregroundStyle(.white)
        }
    }
}

#Preview {
    StateB()
}
