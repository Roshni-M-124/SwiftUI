//
//  GridB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct GridB: View {
    
    let columns: [GridItem] = [
       // GridItem(.fixed(50), spacing: nil, alignment: nil),
       // GridItem(.flexible(), spacing: nil, alignment: nil), //behaves like spacer adjust width to max of available
        GridItem(.adaptive(minimum: 50, maximum: 300), spacing: nil, alignment: nil) ,//if use adaptive in one column itself it will try to fit as many elements as possible by maintaining the minimum width mentiones. so one column doesnot mean one element here .
        GridItem(.adaptive(minimum: 150, maximum: 300), spacing: nil, alignment: nil)
        
        ]
    
    let column2: [GridItem] = [
        GridItem(.flexible(),spacing: 6,alignment: nil), // spacing here is the spacing between columns
        GridItem(.flexible(),spacing: nil,alignment: nil),
        GridItem(.flexible(),spacing: nil,alignment: nil)
        
    ]
    
    var body: some View {
       
        /*
        //grids are by default Lazy
        LazyVGrid(columns:columns ){
            ForEach(0..<50){ index in
                Rectangle()
                    .frame(height: 50)
                
            }
        }
        */
        
        // instagram profile section then below grids with scroll view
        ScrollView{
            Rectangle()
                .fill(.orange)
                .frame(height: 400)
            
            //lazyHGrid just row instead of column and scroll view .horizontal
            
            LazyVGrid(
                columns: column2,
                alignment:.center,
                spacing: nil,//spacing 0 makes spacing between rows to be zero not columns
                pinnedViews: [.sectionHeaders]// to pin headers to top when in that section during scroll
            ){
                    Section(header:
                                Text("Section 1")
                        .foregroundStyle(.white)
                        .font(.title)
                        .frame(maxWidth: .infinity,alignment: .leading)
                        .background(.blue)
                        .padding()
                            
                    ){
                        ForEach(0..<20){ index in
                            Rectangle()
                                .frame(height: 150)
                        }
                    }
                    
                    Section(header:
                                Text("Section 2")
                        .foregroundStyle(.white)
                        .font(.title)
                        .frame(maxWidth: .infinity,alignment: .leading)
                        .background(.red)
                        .padding()
                            
                    ){
                        ForEach(0..<20){ index in
                            Rectangle()
                                .fill(.green)
                                .frame(height: 150)
                        }
                    }
            }
        }
        
    }
}

#Preview {
    GridB()
}
