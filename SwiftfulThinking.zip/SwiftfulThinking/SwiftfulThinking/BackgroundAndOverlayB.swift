//
//  BackgroundAndOverlayB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct BackgroundAndOverlayB: View {
    var body: some View {
       /*
        
        Text("Hello, World!")
            //.frame(width: 120,height:120)
            .background(
                //.red
                //LinearGradient(colors: [.red,.purple], startPoint: .leading, endPoint: .trailing)
                Circle()
                    .fill(LinearGradient(colors: [.red,.blue], startPoint: .leading, endPoint: .trailing))
                    .frame(width: 120,height:120)
            )
            //.frame(width: 150,height: 150)
            .background(
                Circle()
                    .fill(LinearGradient(colors: [.blue,.red], startPoint: .leading, endPoint: .trailing))
                    .frame(width: 150,height: 150)
            )// u can stack backgrounds by adding frames in between either have frames and then background or in background for the shape set the frame
        
        */
        
       /*
        
        Circle()
            .fill(.red)
            .frame(width: 100,height: 100)
            .overlay(
                Text("1")
                    .font(.largeTitle)
                    .foregroundStyle(.white)
            )
            .background(
                Circle()
                    .fill(.purple)
                    .frame(width: 110,height: 110)
            )// now we get another circle as border
        
        */
        
        /*
         
         Rectangle()
            .frame(width: 100,height: 100)
            .overlay(
                Rectangle()
                    .fill(.blue)
                    .frame(width: 50,height: 50)
                ,alignment: .topLeading
            )
            .background(
                Rectangle()
                    .fill(.red)
                    .frame(width: 150,height: 150)
                ,alignment: .bottomTrailing
            )
        //overlays and backgrounds also has alignment
         
         */
        
        // create icon with notification badge using overlay
        
        Image(systemName: "heart.fill")
            .font(.system(size: 40))
            .foregroundStyle(.white)
            .background(
                Circle()
                    .fill(
                        LinearGradient(colors: [.red,.blue], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .frame(width: 100,height: 100)
                    .shadow(color: Color(.black).opacity(0.7),radius: 10,x:0,y:10)
                    .overlay(
                        Circle()
                            .fill(.blue)
                            .frame(width: 35,height: 35)
                            .overlay(
                                Text("5")
                                    .font(.system(size: 20))
                                    .foregroundStyle(.white)
                        ),
                        alignment: .bottomTrailing
                    )
                    
            )
    }
}

#Preview {
    BackgroundAndOverlayB()
}
