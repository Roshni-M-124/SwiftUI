//
//  ScrollViewB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct ScrollViewB: View {
    var body: some View {
        /*
        ScrollView(.horizontal,showsIndicators: true) {
            HStack{
                ForEach(0..<50){index in
                    Rectangle()
                        .fill(.blue)
                        .frame(width: 300,height: 300)
                    
                }
            }
        }
         */
        
        ScrollView{
            LazyVStack{
                ForEach(0..<100){index in
                    ScrollView(.horizontal,showsIndicators: true){
                       LazyHStack{
                            ForEach(0..<200){ index in
                                RoundedRectangle(cornerRadius: 25)
                                    .fill(.white)
                                    .frame(width: 200,height: 200)
                                    .shadow(radius: 10)
                                    .padding()
                            }
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ScrollViewB()
}
