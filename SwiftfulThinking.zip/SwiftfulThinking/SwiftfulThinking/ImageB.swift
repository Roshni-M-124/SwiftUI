//
//  ImageBootcamp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct ImageB: View {
    var body: some View {
        Image("google")
            //.renderingMode(.template)//if u want to make it like an icon and change colour of logo alone render as template but this is for images without background else full image will became red on application of foreground colour as red
        // instead of adding everytime in code go to assets inspector and change rendering mode of that image to template
        
            .resizable()
            //.clipShape(
                //Circle()
                //RoundedRectangle(cornerRadius: 20)
               // Ellipse()
           // )
        // .cornerRadius(150) //in frame have width and height equal and corner radius half of that to make it circle
     
        // .aspectRatio(contentMode: .fit)
            .scaledToFit()
            .foregroundStyle(.red)
            .frame(width: 300,height: 200)
            .border(.black)
    }
}

#Preview {
    ImageB()
}
