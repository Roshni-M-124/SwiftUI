//
//  EnvironmentObjectB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 26/05/26.
//

import SwiftUI
internal import Combine

class EnvironmentViewModel: ObservableObject{
    
    @Published var dataArray: [String] = []
    
    init(){
        getData()
    }
    func getData(){
        self.dataArray.append("iPhone")
        self.dataArray.append("iPad")
        self.dataArray.append(contentsOf: ["iMac","Apple Watch"])
    }
}

struct DetailedView: View {
    
    let selectedItem : String
    
    var body: some View {
        ZStack{
            Color.orange.ignoresSafeArea(.all)
            NavigationLink(destination: FinalView(), label: {
                Text(selectedItem)
                    .font(.headline)
                    .foregroundStyle(.orange)
                    .padding()
                    .padding(.horizontal)
                    .background(.white)
                    .cornerRadius(30)
            })
        }
    }
}

struct EnvironmentObjectB: View {
    
    @StateObject private var viewModel: EnvironmentViewModel = EnvironmentViewModel()
    var body: some View {
        NavigationView{
            List{
                ForEach(viewModel.dataArray, id:\.self){ item in
                    NavigationLink(destination: DetailedView(selectedItem: item), label: {
                        Text(item)
                    })
                   
                    
                }
                .navigationTitle("iOS Devices ")
            }
        }
        .environmentObject(viewModel)
    }
}

struct FinalView: View {
    
    @EnvironmentObject var viewModel: EnvironmentViewModel
    var body: some View {
        ZStack{
            //background
            LinearGradient(gradient: Gradient(colors: [.red,.pink]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            //foreground
            ScrollView{
                VStack(spacing: 20){
                    ForEach(viewModel.dataArray, id: \.self){ item in
                        Text(item)
                    }
                    .foregroundStyle(.white)
                    .font(.largeTitle)
                }
            }
        }
    }
}

#Preview {
    EnvironmentObjectB()
}
