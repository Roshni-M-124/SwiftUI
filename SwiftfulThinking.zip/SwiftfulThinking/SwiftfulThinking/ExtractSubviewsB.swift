//
//  ExtractSubviewsB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct ExtractSubviewsB: View {
    var body: some View {
        ZStack{
            Color.blue.edgesIgnoringSafeArea(.all)
            
            contentLayer
        }
    }
    
    //hstack is same so store it in var 
    var contentLayer: some View{
        HStack{
            MyItem(count: 1, fruit: "Apples", color: .red)
            MyItem(count: 10, fruit: "Oranges", color: .orange)
            MyItem(count: 30, fruit: "Banana", color: .yellow)
        }
    }
}

#Preview {
    ExtractSubviewsB()
}

struct MyItem : View {
    let count: Int
    let fruit: String
    let color: Color
    var body: some View {
        VStack{
            Text("\(count)")
            Text("\(fruit)")
        }
        .padding()
        .background(color)
        .cornerRadius(10)
    }
}
