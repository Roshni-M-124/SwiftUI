//
//  PopOverB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

//present new screen using sheet, transition,animations

import SwiftUI

struct PopOverB: View {
    
    @State var showNewScreen: Bool = false
    
    var body: some View {
        ZStack{
            Color.orange.edgesIgnoringSafeArea(.all)
            
            VStack{
                Button("Button"){
                    showNewScreen.toggle()
                }
                .font(.largeTitle)
                Spacer()
            }
            //METHOD - 1
//            .sheet(isPresented: $showNewScreen, content: {
//                NewScreen()
//            })
            
            //METHOD - 2 - TRANSITION
            
            ZStack{
                if showNewScreen{
                    NewScreen(showNewScreen: $showNewScreen)
                        .padding(.top,100)
                        .transition(.move(edge: .bottom))
                        .animation(.spring(), value: showNewScreen)
                }
            }
            .zIndex(2.0)
            
//            //METHOD - 3 - ANIMATION
//            GeometryReader{ geometry in
//                NewScreen(showNewScreen: $showNewScreen)
//                    .padding(.top,100)
//                    .offset(y: showNewScreen ? 0 : geometry.size.height)
//                    .animation(.spring, value: showNewScreen)
//            }
        }
    }
}

struct NewScreen: View {
    
    @Environment(\.dismiss) var dismiss
    @Binding var showNewScreen: Bool
    
    var body: some View {
        ZStack(alignment: .topLeading){
            Color.purple.edgesIgnoringSafeArea(.all)
            
            Button(action: {
               // dismiss() //M1
                showNewScreen.toggle()
                
            }, label: {
                Image(systemName: "xmark")
                    .foregroundStyle(.white)
                    .font(.largeTitle)
                    .padding(20)
            })
            
        }
    }
}

#Preview {
    PopOverB()
}
