//
//  ColorBootcamp.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 20/05/26.
//

import SwiftUI

struct ColorB: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(
            //.blue
            //  .primary // in light mode primary is black and secondary is white and in dark mode vice versa use this to change font colour based on mode
           //     Color(UIColor.secondarySystemBackground)
                Color("CustomColor") // to use color from assets
                
                
            )
            .frame(width: 200,height: 100)
            //.shadow(radius: 10)
            .shadow(color: Color("CustomColor").opacity(0.3), radius: 20,x: -20,y:-20 )
            
    }
}

#Preview {
    ColorB()
}
