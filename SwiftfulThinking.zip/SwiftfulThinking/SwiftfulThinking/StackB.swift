//
//  StackB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 21/05/26.
//

import SwiftUI

struct StackB: View {
    // VStack -> Vertical
    // HStack -> Horizontal
    // ZStack -> zIndex(back to front)
    
    var body: some View {
        VStack(alignment: .leading,spacing: 0)// even if spacing is set to nil it will apply a default value of 8 . set spacing to be 0 to have no space between elements
        {
            Rectangle()
                .fill(.red)
                .frame(width: 200,height: 200) // at bottom in z
            
            Rectangle()
                .fill(.orange)
                .frame(width: 150,height: 150)// mid in z
            
            Rectangle()
                .fill(.purple)
                .frame(width: 100,height: 100)// top in z
        }
        
        // ztack with circle and text is same as text with background of circle . but zstack is useful when u want to stack multiple frames
        
    }
}

#Preview {
    StackB()
}
