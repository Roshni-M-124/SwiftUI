//
//  BindingB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct BindingB: View {
    @State var backgroundColour:Color = .green
    @State var title:String = "Title"
    
    var body: some View {
        ZStack{
            backgroundColour.edgesIgnoringSafeArea(.all)
            VStack{
                Text("\(title)")
                    .foregroundStyle(.white)
                    .font(.largeTitle)
                ButtonView(backgroundColour: $backgroundColour,title: $title)
            }
           
            //if changing background color in the same view @state is sufficient . If u pass to other view and want that view to modify this view use binding in the child
        }
    }
}

struct ButtonView: View {
    
    @Binding var backgroundColour:Color
    @Binding var title:String 
    @State var buttonColor : Color = .blue
    
    var body: some View {
        Button(action: {
            backgroundColour = Color.orange
            buttonColor = .pink
            title = "Button pressed"
        }, label: {
            Text("Button")
                .foregroundStyle(.white)
                .padding()
                .padding(.horizontal,10)
                .background(buttonColor)
                .cornerRadius(10)
        })
    }
}

#Preview {
    BindingB()
}
