//
//  TransitionB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct TransitionB: View {
    
    @State var showView: Bool = false
    
    var body: some View {
        ZStack(alignment:.bottom ){
            
            VStack{
                Button("Button"){
                    withAnimation(.easeInOut){
                        showView.toggle()
                    }
                }
                Spacer()
            }
            GeometryReader{ geometry in
                VStack{
                    Spacer()
                    if showView{
                        RoundedRectangle(cornerRadius: 20)
                            .frame(height: geometry.size.height * 0.5)
                           // .transition(.slide)
                           // .transition(.move(edge: .bottom))
                            //.transition(AnyTransition.opacity.animation(.easeInOut))
                        //instead of opacity use scale to make it zoom in and zoom out
                            .transition(
                                .asymmetric(
                                    insertion: .move(edge: .leading),
                                    removal: AnyTransition.opacity.animation(.easeInOut)
                                ))
                    }
                }
                
            }
        }
        .ignoresSafeArea(edges:.bottom)
    }
}

#Preview {
    TransitionB()
}
