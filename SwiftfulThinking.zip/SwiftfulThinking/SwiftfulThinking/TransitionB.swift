//
//  TransitionB.swift
//  SwiftfulThinking
//
//  Created by Mobicip on 22/05/26.
//

import SwiftUI

struct TransitionB: View {
    var body: some View {
        ZStack(alignment: .bottom){
            
            VStack{
                Button("Button"){
                    
                }
                Spacer()
            }
            RoundedRectangle(cornerRadius: 20)
                .frame(width: 100,height: 100)
        }
    }
}

#Preview {
    TransitionB()
}
