//
//  weatherAppApp.swift
//  weatherApp
//
//  Created by Mobicip on 19/05/26.
//

import SwiftUI

@main
struct weatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
