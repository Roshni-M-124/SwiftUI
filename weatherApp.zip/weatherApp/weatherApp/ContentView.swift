//
//  ContentView.swift
//  weatherApp
//
//  Created by Mobicip on 19/05/26.
//

import SwiftUI
let gradient: [Color] = [.gradientTop, .gradientBottom]
struct ContentView: View {
    var body: some View {
        VStack(spacing: 30) {
            Text("Weather")
                .font(.largeTitle)
                .fontDesign(.serif)
                .fontWeight(.medium)
                .padding(.top, 120)
                .padding(.bottom, 30)
            HStack {
                DayForecast(day: "Mon",isRainy: false, high: 70, low: 50)
                DayForecast(day: "Tue", isRainy: true, high: 60, low: 40)
                DayForecast(day: "Wed", isRainy: false, high: 68, low: 55)
            }
            HStack{
                DayForecast(day: "Thu", isRainy: true, high: 40, low: 20)
                DayForecast(day: "Fri", isRainy: true, high: 35, low: 25)
                DayForecast(day: "Sat", isRainy: false, high: 65, low: 55)
            }
            Spacer()
        }
        .frame(maxHeight: .infinity)
        .padding(20)
        .background(LinearGradient(colors: gradient, startPoint: .topTrailing, endPoint: .bottomLeading))
        
    }
       
}

struct DayForecast: View {
    let day: String
    let isRainy: Bool
    var iconName: String{
        if isRainy{
            return "cloud.rain.fill"
        }
        else{
            return "sun.max.fill"
        }
    }
    var iconColour: Color{
        if isRainy{
            return Color.blue
        }
        else{
            return Color.yellow
        }
    }
    let high: Int
    let low: Int
    var body: some View {
        VStack{
            Text(day)
                .font(Font.title2)
            Image(systemName: iconName)
                .foregroundStyle(iconColour)
            Text("High: \(high) °C")
                .fontWeight(Font.Weight.semibold)
                .padding(5)
            Text("Low: \(low) °C")
                .fontWeight(Font.Weight.medium)
                .foregroundStyle(Color.secondary)
        }
        .padding(.top,5)
        .padding(.bottom,5)
        .frame(width: 115)
        .background{
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.blue.opacity(0.6))
                .brightness(-0.3)
        }
        .padding(.trailing,8)
    }
}

#Preview {
    ContentView()
}
